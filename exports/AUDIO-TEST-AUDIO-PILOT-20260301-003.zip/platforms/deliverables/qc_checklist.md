# QC Checklist (Defaults)

- [ ] No clipping; true-peak within target.
- [ ] Phase/mono compatibility check (where relevant).
- [ ] Noise floor acceptable for voice/podcast deliverables.
- [ ] Start/end clean (no clicks), fades where required.
- [ ] Deliverables naming matches pattern.
- [ ] Metadata notes captured (genre/mood/BPM/key).
