# Deliverables Naming

**Root:** `TEST-AUDIO-PILOT_Test_Audio_Pilot`

**Pattern:** `{PROJECT}_{TITLE}_{TYPE}_{BPM}_{KEY}_{VERSION}`

## Examples
- `TEST-AUDIO-PILOT_Test_Audio_Pilot_MASTER_120_AMIN_v01.wav`
- `TEST-AUDIO-PILOT_Test_Audio_Pilot_STEM_DRUMS_120_AMIN_v01.wav`
- `TEST-AUDIO-PILOT_Test_Audio_Pilot_ALT_SHORT_120_AMIN_v02.wav`

Keep filenames ASCII-safe; avoid spaces; use consistent versioning.
