# YouTube Title + Description

Title: Test Audio Pilot (Cinematic) | 120 BPM

Description:
- Mood: Epic
- BPM/Key: 120 / A minor
- Credits: (fill)
- Links: (fill)
