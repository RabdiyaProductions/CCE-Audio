# TikTok / Reels Caption

**Test Audio Pilot** — Cinematic / Epic

BPM: 120 | Key: A minor

Hook idea: 2–3 seconds of motif + drop.

Hashtags: #music #producer #newmusic #Cinematic #fyp
