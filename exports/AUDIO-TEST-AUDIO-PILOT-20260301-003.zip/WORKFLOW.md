# CCE Audio Workflow (Internal)

1) Studio Hub submits order
2) CCE Audio generates pack
3) Critique + founder signoff
4) Export pack
5) Studio Hub schedules/publishes
